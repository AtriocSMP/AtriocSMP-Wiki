

execute as @a run execute as @r run function foolwave:grub_summon


execute as @a as @s[tag=debuff1] at @s[tag=debuff1] run effect give @s[tag=debuff1] minecraft:slowness infinite 0
execute as @a as @s[tag=debuff2] at @s[tag=debuff2] run effect give @s[tag=debuff2] minecraft:mining_fatigue infinite 0
execute as @a as @s[tag=debuff3] at @s[tag=debuff3] run effect give @s[tag=debuff3] minecraft:nausea infinite 0
execute as @a as @s[tag=debuff4] at @s[tag=debuff4] run effect give @s[tag=debuff4] minecraft:blindness infinite 0
execute as @a as @s[tag=debuff5] at @s[tag=debuff5] run effect give @s[tag=debuff5] minecraft:hunger infinite 0
execute as @a as @s[tag=debuff6] at @s[tag=debuff6] run effect give @s[tag=debuff6] minecraft:weakness infinite 0
execute as @a as @s[tag=debuff7] at @s[tag=debuff7] run effect give @s[tag=debuff7] minecraft:poison infinite 0
execute as @a as @s[tag=debuff8] at @s[tag=debuff8] run effect give @s[tag=debuff8] minecraft:bad_omen infinite 0
execute as @a as @s[tag=debuff9] at @s[tag=debuff9] run effect give @s[tag=debuff9] minecraft:levitation infinite 0
execute as @a as @s[tag=debuff10] at @s[tag=debuff10] run effect give @s[tag=debuff10] minecraft:darkness infinite 0