
effect give @s minecraft:strength 15 4

advancement revoke @s only foolwave:story/chungus_style_porkchop