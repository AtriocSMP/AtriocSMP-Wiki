
effect give @s minecraft:resistance 15 4

advancement revoke @s only foolwave:story/big_potato