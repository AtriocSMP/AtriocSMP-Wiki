
effect give @s minecraft:levitation 15 4

advancement revoke @s only foolwave:story/godly_chicken