
effect give @s minecraft:hunger 15 0
effect give @s minecraft:nausea 10 0
effect give @s minecraft:poison 5 0

advancement revoke @s only foolwave:story/rotten_sandwich