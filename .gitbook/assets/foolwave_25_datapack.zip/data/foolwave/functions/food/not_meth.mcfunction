
effect give @s minecraft:speed 15 4

advancement revoke @s only foolwave:story/not_meth