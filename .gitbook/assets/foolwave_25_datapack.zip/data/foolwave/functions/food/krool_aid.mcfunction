
effect give @s minecraft:regeneration 15 4

advancement revoke @s only foolwave:story/krool_aid