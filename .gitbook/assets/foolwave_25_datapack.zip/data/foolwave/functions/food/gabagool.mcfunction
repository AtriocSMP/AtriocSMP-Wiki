
effect give @s minecraft:absorption 15 4

advancement revoke @s only foolwave:story/gabagool