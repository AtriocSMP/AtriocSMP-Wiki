
effect give @s minecraft:saturation 20 4

advancement revoke @s only foolwave:story/orange