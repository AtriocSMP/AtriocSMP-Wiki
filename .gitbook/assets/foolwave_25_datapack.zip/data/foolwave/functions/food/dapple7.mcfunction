
effect give @s minecraft:haste 15 4

advancement revoke @s only foolwave:story/dapple7