

give @s minecraft:allay_spawn_egg{EntityTag:{id:"minecraft:armor_stand",Tags:["armor_table"]}} 64