

execute as @s at @s run tag @a[distance=..3] remove debuff1
execute as @s at @s run tag @a[distance=..3] remove debuff2
execute as @s at @s run tag @a[distance=..3] remove debuff3
execute as @s at @s run tag @a[distance=..3] remove debuff4
execute as @s at @s run tag @a[distance=..3] remove debuff5
execute as @s at @s run tag @a[distance=..3] remove debuff6
execute as @s at @s run tag @a[distance=..3] remove debuff7
execute as @s at @s run tag @a[distance=..3] remove debuff8
execute as @s at @s run tag @a[distance=..3] remove debuff9
execute as @s at @s run tag @a[distance=..3] remove debuff10

execute as @s at @s run effect clear @a[distance=..3] minecraft:slowness
execute as @s at @s run effect clear @a[distance=..3] minecraft:mining_fatigue
execute as @s at @s run effect clear @a[distance=..3] minecraft:nausea
execute as @s at @s run effect clear @a[distance=..3] minecraft:blindness
execute as @s at @s run effect clear @a[distance=..3] minecraft:hunger
execute as @s at @s run effect clear @a[distance=..3] minecraft:weakness
execute as @s at @s run effect clear @a[distance=..3] minecraft:poison
execute as @s at @s run effect clear @a[distance=..3] minecraft:bad_omen
execute as @s at @s run effect clear @a[distance=..3] minecraft:levitation
execute as @s at @s run effect clear @a[distance=..3] minecraft:darkness


scoreboard players enable @s heal

scoreboard players set @s heal 0