
execute as @s at @s run summon minecraft:block_display ~ ~ ~ {Tags:["crafter"],block_state:{Name:"minecraft:composter"},transformation:{left_rotation:[1.0f,0.0f,0.0f,0.0f],translation:[-0.51f,0.0f,-0.51f],right_rotation:[1.0f,0.0f,0.0f,0.0f],scale:[1.02f,1.02f,1.02f]}}
execute as @s at @s run data modify entity @e[type=minecraft:block_display,sort=nearest,limit=1] Pos[2] set from entity @s Pos[2]
execute as @s at @s run data modify entity @e[type=minecraft:block_display,sort=nearest,limit=1] Pos[1] set from entity @s Pos[1]
execute as @s at @s run data modify entity @e[type=minecraft:block_display,sort=nearest,limit=1] Pos[0] set from entity @s Pos[0]

execute as @s at @s run setblock ~ ~ ~ minecraft:dispenser

execute as @s run kill @s