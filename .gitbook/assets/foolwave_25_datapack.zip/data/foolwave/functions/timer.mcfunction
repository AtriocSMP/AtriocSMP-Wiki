
# Loop
scoreboard players add TimerPlayer grubtimer 1

# Heal
execute as @a as @s if score @s heal matches 1 run function foolwave:cure

# Main
execute if score TimerPlayer grubtimer matches 2 run function foolwave:grub

execute if score TimerPlayer grubtimer matches 4 run function foolwave:main
execute if score TimerPlayer grubtimer matches 24 run function foolwave:main
execute if score TimerPlayer grubtimer matches 44 run function foolwave:main
execute if score TimerPlayer grubtimer matches 64 run function foolwave:main
execute if score TimerPlayer grubtimer matches 84 run function foolwave:main

# Reset
execute if score TimerPlayer grubtimer matches 100.. run scoreboard players set TimerPlayer grubtimer 0
