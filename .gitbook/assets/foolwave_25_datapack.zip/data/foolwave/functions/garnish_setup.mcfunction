



advancement revoke @s only foolwave:story/garnish

execute as @e[type=minecraft:armor_stand,tag=armor_table,sort=nearest,limit=1] at @s run function foolwave:armor_setup

