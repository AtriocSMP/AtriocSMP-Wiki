

scoreboard players enable Holli333 heal


execute as @e[tag=crafter] at @s run function foolwave:garnish
