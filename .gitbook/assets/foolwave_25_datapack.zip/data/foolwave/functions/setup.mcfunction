scoreboard objectives add grubtimer dummy

scoreboard objectives add heal trigger

scoreboard objectives add roll dummy

scoreboard objectives add height dummy