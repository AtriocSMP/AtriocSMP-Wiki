


execute store result score @s height run data get entity @s Pos[1]

execute store result score .rnggrub roll run random value 1..10

execute as @s at @s if score @s height matches ..0 run summon silverfish


execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 1 run tag @s add debuff1
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 2 run tag @s add debuff2
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 3 run tag @s add debuff3
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 4 run tag @s add debuff4
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 5 run tag @s add debuff5
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 6 run tag @s add debuff6
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 7 run tag @s add debuff7
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 8 run tag @s add debuff8
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 9 run tag @s add debuff9
execute as @s at @s if score @s height matches ..0 if score .rnggrub roll matches 10 run tag @s add debuff10
