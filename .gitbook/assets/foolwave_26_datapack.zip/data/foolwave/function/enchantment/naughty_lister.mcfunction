
scoreboard players set @s naughty_temp 0
scoreboard players set @s naughty 0

execute store result score @s naughty run data get entity @s equipment.head.components.minecraft:enchantments.minecraft:naughty_lister

scoreboard players operation @s naughty_temp += @s naughty

execute store result score @s naughty run data get entity @s equipment.chest.components.minecraft:enchantments.minecraft:naughty_lister

scoreboard players operation @s naughty_temp += @s naughty

execute store result score @s naughty run data get entity @s equipment.legs.components.minecraft:enchantments.minecraft:naughty_lister

scoreboard players operation @s naughty_temp += @s naughty

execute store result score @s naughty run data get entity @s equipment.feet.components.minecraft:enchantments.minecraft:naughty_lister

scoreboard players operation @s naughty_temp += @s naughty



execute store result score @s naughty run random value 1..20

execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 1 run give @s coal 1
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 2 run give @s coal 2
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 3 run give @s coal 3
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 4 run give @s coal 4
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 5 run give @s coal 5
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 6 run give @s coal 6
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 7 run give @s coal 7
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 8 run give @s coal 8
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 9 run give @s coal 9
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 10 run give @s coal 10
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 11 run give @s coal 11
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 12 run give @s coal 12
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 13 run give @s coal 13
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 14 run give @s coal 14
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 15 run give @s coal 15
execute if score @s naughty matches 1 run execute if score @s naughty_temp matches 16 run give @s coal 16
