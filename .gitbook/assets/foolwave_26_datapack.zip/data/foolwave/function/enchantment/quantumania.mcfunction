
execute store result score @s quantumania run random value 1..31

execute if score @s quantumania matches 1 run attribute @s minecraft:scale base set 0.0625
execute if score @s quantumania matches 2 run attribute @s minecraft:scale base set 0.125
execute if score @s quantumania matches 3 run attribute @s minecraft:scale base set 0.1875
execute if score @s quantumania matches 4 run attribute @s minecraft:scale base set 0.25
execute if score @s quantumania matches 5 run attribute @s minecraft:scale base set 0.3125
execute if score @s quantumania matches 6 run attribute @s minecraft:scale base set 0.375
execute if score @s quantumania matches 7 run attribute @s minecraft:scale base set 0.4375
execute if score @s quantumania matches 8 run attribute @s minecraft:scale base set 0.5
execute if score @s quantumania matches 9 run attribute @s minecraft:scale base set 0.5625
execute if score @s quantumania matches 10 run attribute @s minecraft:scale base set 0.625
execute if score @s quantumania matches 11 run attribute @s minecraft:scale base set 0.6875
execute if score @s quantumania matches 12 run attribute @s minecraft:scale base set 0.75
execute if score @s quantumania matches 13 run attribute @s minecraft:scale base set 0.8125
execute if score @s quantumania matches 14 run attribute @s minecraft:scale base set 0.875
execute if score @s quantumania matches 15 run attribute @s minecraft:scale base set 0.9375
execute if score @s quantumania matches 16 run attribute @s minecraft:scale base set 1
execute if score @s quantumania matches 17 run attribute @s minecraft:scale base set 2
execute if score @s quantumania matches 18 run attribute @s minecraft:scale base set 3
execute if score @s quantumania matches 19 run attribute @s minecraft:scale base set 4
execute if score @s quantumania matches 20 run attribute @s minecraft:scale base set 5
execute if score @s quantumania matches 21 run attribute @s minecraft:scale base set 6
execute if score @s quantumania matches 22 run attribute @s minecraft:scale base set 7
execute if score @s quantumania matches 23 run attribute @s minecraft:scale base set 8
execute if score @s quantumania matches 24 run attribute @s minecraft:scale base set 9
execute if score @s quantumania matches 25 run attribute @s minecraft:scale base set 10
execute if score @s quantumania matches 26 run attribute @s minecraft:scale base set 11
execute if score @s quantumania matches 27 run attribute @s minecraft:scale base set 12
execute if score @s quantumania matches 28 run attribute @s minecraft:scale base set 13
execute if score @s quantumania matches 29 run attribute @s minecraft:scale base set 14
execute if score @s quantumania matches 30 run attribute @s minecraft:scale base set 15
execute if score @s quantumania matches 31 run attribute @s minecraft:scale base set 16
