
execute store result score @s karma run data get entity @s SelectedItem.components.minecraft:enchantments.minecraft:karma

execute at @e[nbt={last_hurt_by_player_memory_time:100},sort=nearest] run execute if score @s karma matches 1 run loot spawn ~ ~ ~ loot minecraft:enchantment/karma
execute at @e[nbt={last_hurt_by_player_memory_time:100},sort=nearest] run execute if score @s karma matches 2 run loot spawn ~ ~ ~ loot minecraft:enchantment/karma2
execute at @e[nbt={last_hurt_by_player_memory_time:100},sort=nearest] run execute if score @s karma matches 3 run loot spawn ~ ~ ~ loot minecraft:enchantment/karma3
execute at @e[nbt={last_hurt_by_player_memory_time:100},sort=nearest] run execute if score @s karma matches 4 run loot spawn ~ ~ ~ loot minecraft:enchantment/karma4
execute at @e[nbt={last_hurt_by_player_memory_time:100},sort=nearest] run execute if score @s karma matches 5 run loot spawn ~ ~ ~ loot minecraft:enchantment/karma5