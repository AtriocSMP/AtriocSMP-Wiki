
execute as @e[type=minecraft:rabbit,nbt={RabbitType:99}] run function foolwave:big_chungus_grow


#execute as @a as @s run execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{chungite:"true"}}}}] run function 

#execute as @a as @s run execute if score @s creative_timer matches 1.. run function foolwave:creative_timer

execute as @a as @s run execute if score @s brainrot_time matches 1.. run function foolwave:brainrot_active_text

execute as @a as @s at @s run execute if score @s jj_timer matches 1.. run function foolwave:jj_timer

execute as @e[type=minecraft:armor_stand,tag=ping,sort=nearest] unless predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"vehicle":{}}} run kill @s

function foolwave:kickball

execute as @a as @s run execute unless entity @s[nbt={equipment:{head:{}}}] run team leave @s

execute as @a as @s run attribute @s minecraft:fall_damage_multiplier base set 1.2

execute as @e[type=minecraft:drowned,tag=!ping,sort=random,limit=1] at @s run function foolwave:ping_ray