scoreboard objectives add karma dummy
scoreboard objectives add quantumania dummy
scoreboard objectives add fool_timer dummy
scoreboard objectives add chungus_size dummy
scoreboard objectives add creative_timer dummy
scoreboard objectives add brainrot_time dummy
scoreboard objectives add jj_timer dummy
scoreboard objectives add kickball dummy
scoreboard objectives add worm dummy
scoreboard objectives add rumcoin dummy
scoreboard objectives add glumbox minecraft.mined:minecraft.suspicious_sand
scoreboard objectives add ping_spawn dummy
scoreboard objectives add naughty dummy
scoreboard objectives add naughty_temp dummy
scoreboard objectives add nick dummy
scoreboard objectives add scurvy dummy


scoreboard objectives add x_player dummy
scoreboard objectives add y_player dummy
scoreboard objectives add z_player dummy
scoreboard objectives add x_temp dummy
scoreboard objectives add y_temp dummy
scoreboard objectives add z_temp dummy
scoreboard objectives add y_barrel dummy

team add bones

scoreboard objectives add chung_pick minecraft.used:minecraft.netherite_pickaxe
scoreboard objectives add chung_shovel minecraft.used:minecraft.netherite_shovel
scoreboard objectives add chung_hoe minecraft.used:minecraft.netherite_hoe