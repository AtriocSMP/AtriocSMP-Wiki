#title @s times 0t 2s 0t

#execute if score @s brainrot_time matches 6880..6960 run title @s title {"text":"We're no strangers to love","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6800..6880 run title @s title {"text":"You know the rules and so do I","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6720..6800 run title @s title {"text":"A full commitment's what I'm thinking of","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6640..6720 run title @s title {"text":"You wouldn't get this from any other guy","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6540..6640 run title @s title {"text":"I just wanna tell you how I'm feeling","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6480..6540 run title @s title {"text":"Gotta make you understand","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6440..6480 run title @s title {"text":"Never gonna give you up","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6400..6440 run title @s title {"text":"Never gonna let you down","color":"dark_aqua"}
#execute if score @s brainrot_time matches 6320..6400 run title @s title {"text":"Never gonna run around and desert you","color":"dark_aqua"}

#execute if score @s brainrot_time matches 1..6320 run title @s title {"text":"","color":"dark_aqua"}

execute if score @s brainrot_time matches 1 run scoreboard players set @s brainrot_time 0

#19
#23
#27
#31
#35
#40
#43
#45
#47
#51


