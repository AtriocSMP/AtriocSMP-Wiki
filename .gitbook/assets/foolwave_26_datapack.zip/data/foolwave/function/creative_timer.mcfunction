
scoreboard players remove @s creative_timer 1

function foolwave:fly_stop with storage fly