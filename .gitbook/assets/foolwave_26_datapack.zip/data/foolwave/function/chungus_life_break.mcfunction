
execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{chungite:"break"}}}}] run effect give @s minecraft:saturation 1 0

scoreboard players set @s chung_pick 0
scoreboard players set @s chung_shovel 0
scoreboard players set @s chung_hoe 0
