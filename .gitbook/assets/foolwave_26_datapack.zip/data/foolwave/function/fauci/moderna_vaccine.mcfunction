advancement revoke @s only minecraft:foolwave/moderna_vaccine

effect clear @s
effect give @s minecraft:weakness 60 1