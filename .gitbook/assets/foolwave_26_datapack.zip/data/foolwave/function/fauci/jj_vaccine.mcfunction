advancement revoke @s only minecraft:foolwave/jj_vaccine

scoreboard players set @s jj_timer 4