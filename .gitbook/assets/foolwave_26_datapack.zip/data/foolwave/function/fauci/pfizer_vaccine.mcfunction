advancement revoke @s only minecraft:foolwave/pfizer_vaccine

playsound minecraft:item.brainrot.sound.pfizer master @s ~ ~ ~ 1000000000000000000 