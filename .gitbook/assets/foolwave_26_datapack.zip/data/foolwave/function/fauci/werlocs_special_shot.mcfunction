advancement revoke @s only minecraft:foolwave/werlocs_special_shot

effect give @s minecraft:absorption 10 4
effect give @s minecraft:conduit_power 10 0
effect give @s minecraft:haste 10 2
effect give @s minecraft:health_boost 10 4
effect give @s minecraft:instant_health 1 5
effect give @s minecraft:regeneration 10 4
effect give @s minecraft:saturation 10 4
effect give @s minecraft:resistance 10 4
effect give @s minecraft:strength 10 4
effect give @s minecraft:speed 10 4