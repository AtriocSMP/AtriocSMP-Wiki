
execute store result score ping_spawn ping_spawn run random value 1..4

execute if score ping_spawn ping_spawn matches 2.. run tag @s add ping
execute if score ping_spawn ping_spawn matches 1 run summon minecraft:guardian ~ ~ ~ {CustomName:"Ping Ray",Health:50,attributes:[{id:attack_damage,base:15f},{id:max_health,base:50f}],DeathLootTable:"entities/ping_ray",active_effects:[{duration:-1,id:"minecraft:invisibility",show_particles:0b}],NoAI:0b,Passengers:[{id:armor_stand,Small:1b,Invulnerable:1b,Tags:["ping"],Invisible:1b,equipment:{head:{id:flint,components:{item_model:ping_ray}}}}]}
execute if score ping_spawn ping_spawn matches 1 run kill @s
