
item replace entity @s armor.head with minecraft:player_head[minecraft:custom_name={text:"Ancient Head",color:dark_aqua,italic:0b},minecraft:enchantments={binding_curse:1,bone_brigade:1},profile={id:[I;1514992520,-821993703,-2074213162,-1216554987],properties:[{name:"textures",value:"e3RleHR1cmVzOntTS0lOOnt1cmw6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTkwYWI2MjlmYWFkOGM5YTIwODFiNTY1ZWExYTIzODE0MWVjMmY0ZGViMjZjZGMzNTNiYmYxNWJlYWZkYzBhZCJ9fX0="}]}]
team join bones @s 
advancement revoke @s only minecraft:foolwave/ancient_curse