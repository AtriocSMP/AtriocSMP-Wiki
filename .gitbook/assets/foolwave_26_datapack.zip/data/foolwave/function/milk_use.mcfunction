
stopsound @s master minecraft:item.brainrot.sound.rickroll

scoreboard players set @s brainrot_time 0

advancement revoke @s only minecraft:foolwave/milk_use