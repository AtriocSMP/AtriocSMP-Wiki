

scoreboard players set @s glumbox 0

execute store result score glumbox glumbox run random value 1..19



execute if score glumbox glumbox matches 1 run function foolwave:glumbox/lock_in
execute if score glumbox glumbox matches 2 run function foolwave:glumbox/1_19
execute if score glumbox glumbox matches 3 run function foolwave:glumbox/pride
execute if score glumbox glumbox matches 4 run function foolwave:glumbox/behold_greatness
execute if score glumbox glumbox matches 5 run function foolwave:glumbox/intimidate
execute if score glumbox glumbox matches 6 run function foolwave:glumbox/haste
execute if score glumbox glumbox matches 7 run function foolwave:glumbox/perish_song
execute if score glumbox glumbox matches 8 run function foolwave:glumbox/max_guard
execute if score glumbox glumbox matches 9 run function foolwave:glumbox/rumcoin
execute if score glumbox glumbox matches 10 run function foolwave:glumbox/kickball
execute if score glumbox glumbox matches 11 run function foolwave:glumbox/trans_rights
execute if score glumbox glumbox matches 12 run function foolwave:glumbox/bugs_bunny
execute if score glumbox glumbox matches 13 run function foolwave:glumbox/top_dollar
execute if score glumbox glumbox matches 14 run function foolwave:glumbox/shrimp_check
execute if score glumbox glumbox matches 15 run function foolwave:glumbox/gaydar
execute if score glumbox glumbox matches 16 run function foolwave:glumbox/shmungception
execute if score glumbox glumbox matches 17 run function foolwave:glumbox/absolutely_canniballin
execute if score glumbox glumbox matches 18 run function foolwave:glumbox/gun
execute if score glumbox glumbox matches 19 run function foolwave:glumbox/pizza_time


