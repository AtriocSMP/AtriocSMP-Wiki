
#scoreboard players set @s creative_timer 10

advancement revoke @s only minecraft:foolwave/creative
tellraw @s {text:"You so High you can Fly!",color:white,italic:0b,bold:1b}

gamemode creative @s