
scoreboard players add FoolPlayer fool_timer 1

execute if score FoolPlayer fool_timer matches 2 run function foolwave:main

execute if score FoolPlayer fool_timer matches 20.. run scoreboard players set FoolPlayer fool_timer 0


execute as @a as @s run execute if score @s chung_pick matches 1.. run function foolwave:chungus_life_break 
execute as @a as @s run execute if score @s chung_shovel matches 1.. run function foolwave:chungus_life_break 
execute as @a as @s run execute if score @s chung_hoe matches 1.. run function foolwave:chungus_life_break 

execute as @a as @s run execute if score @s glumbox matches 1.. run function foolwave:glumbox