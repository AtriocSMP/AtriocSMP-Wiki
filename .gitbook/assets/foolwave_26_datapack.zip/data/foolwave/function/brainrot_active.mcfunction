
execute store result score @s brainrot_time run data get entity @s active_effects[{id:"minecraft:unluck"}].duration

execute if score @s brainrot_time matches 7339 run stopsound @s master minecraft:item.brainrot.sound.rickroll
execute if score @s brainrot_time matches 7339 run playsound minecraft:item.brainrot.sound.rickroll master @s ~ ~ ~ 1000000000000000000 


advancement revoke @s only minecraft:foolwave/brainrot