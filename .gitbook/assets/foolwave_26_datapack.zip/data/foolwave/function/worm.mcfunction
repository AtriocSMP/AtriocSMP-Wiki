advancement revoke @s only minecraft:foolwave/worm
advancement revoke @s only minecraft:foolwave/worm_squirm1
advancement revoke @s only minecraft:foolwave/worm_squirm2
advancement revoke @s only minecraft:foolwave/worm_squirm3

execute store result score worm worm run random value 1..50


execute if score worm worm matches 1 run loot give @s loot minecraft:gameplay/worm