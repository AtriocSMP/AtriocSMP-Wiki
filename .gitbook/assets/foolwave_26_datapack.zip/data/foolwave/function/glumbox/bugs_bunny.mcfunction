
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Bugs Bunny Ass Death","bold":true,"hover_event":{"action":"show_text","value":"bla"}},{"text":"]","bold":true,"color":"#141026"}]

execute as @s at @s run setblock ~ ~ ~ minecraft:torch 
execute as @s at @s run setblock ~ ~4 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~7 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~10 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~13 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~16 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~19 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~21 ~ minecraft:anvil
execute as @s at @s run setblock ~ ~24 ~ minecraft:anvil