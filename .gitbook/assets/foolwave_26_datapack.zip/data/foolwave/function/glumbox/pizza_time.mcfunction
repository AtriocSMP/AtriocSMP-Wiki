
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Pizza Time","bold":true,"hover_event":{"action":"show_text","value":"I Smell Pepperoni"}},{"text":"]","bold":true,"color":"#141026"}]

execute store result score @s x_player run data get entity @s Pos[0]
execute store result score @s y_player run data get entity @s Pos[1]
execute store result score @s z_player run data get entity @s Pos[2]

execute store result score @s x_temp run random value 15..50
execute store result score @s y_temp run random value 15..50
execute store result score @s z_temp run random value 15..50

scoreboard players set @s y_barrel 1

scoreboard players operation @s x_player += @s x_temp
execute if score @s y_player matches ..0 run scoreboard players operation @s y_player += @s y_temp
execute if score @s y_player matches 1.. run scoreboard players operation @s y_player -= @s y_temp
scoreboard players operation @s z_player += @s z_temp

execute store result storage pizza x_pizza int 1 run scoreboard players get @s x_player
execute store result storage pizza y_pizza int 1 run scoreboard players get @s y_player
execute store result storage pizza z_pizza int 1 run scoreboard players get @s z_player

scoreboard players operation @s y_player += @s y_barrel
execute store result storage pizza y_barrel int 1 run scoreboard players get @s y_player


execute as @s at @s run function foolwave:pizza_time_spawn with storage pizza