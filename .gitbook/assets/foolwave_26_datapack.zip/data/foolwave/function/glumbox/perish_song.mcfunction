
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Perish Song","bold":true,"hover_event":{"action":"show_text","value":"This Song Slaps"}},{"text":"]","bold":true,"color":"#141026"}]

effect give @s minecraft:unluck 367 0