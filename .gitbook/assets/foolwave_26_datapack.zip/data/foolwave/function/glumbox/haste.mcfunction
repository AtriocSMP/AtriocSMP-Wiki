
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Haste","bold":true,"hover_event":{"action":"show_text","value":"I YEARN FOR THE MINES"}},{"text":"]","bold":true,"color":"#141026"}]


effect give @s minecraft:haste 60 9
effect give @s minecraft:speed 60 9