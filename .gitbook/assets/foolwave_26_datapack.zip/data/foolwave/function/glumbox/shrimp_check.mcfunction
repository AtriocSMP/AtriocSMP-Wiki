
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Shrimp Check","bold":true,"hover_event":{"action":"show_text","value":"Shrimp Check!"}},{"text":"]","bold":true,"color":"#141026"}]

execute at @s run title @s title {text:"Shrimp Check",color:"red",bold:true}
execute at @s run title @a[distance=..50] title {text:"Shrimp Check",color:"red",bold:true}