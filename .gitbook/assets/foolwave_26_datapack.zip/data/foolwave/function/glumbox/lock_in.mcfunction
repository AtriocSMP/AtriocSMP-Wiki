tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"LOCK IN","bold":true,"hover_event":{"action":"show_text","value":"LOCK IN!"}},{"text":"]","bold":true,"color":"#141026"}]

title @s times 5t 2s 5t 
title @s title {text:"LOCK IN",color:"red",italic:0b,bold:true}
execute as @s at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1000