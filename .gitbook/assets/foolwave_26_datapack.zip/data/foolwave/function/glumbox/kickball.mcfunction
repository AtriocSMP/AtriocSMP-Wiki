
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Kickball","bold":true,"hover_event":{"action":"show_text","value":"POGGIES"}},{"text":"]","bold":true,"color":"#141026"}]

playsound minecraft:item.brainrot.sound.kickball master @a ~ ~ ~ 100