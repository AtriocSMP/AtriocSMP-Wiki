
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"1 & 19 more","bold":true,"hover_event":{"action":"show_text","value":"Get 1 Diamond and 19 Gold Crates"}},{"text":"]","bold":true,"color":"#141026"}]

execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/temp/crate/1_19