
tellraw @s ["",{"text":"Gl","bold":true,"color":"#E2D3FF"},{"text":"um","bold":true,"color":"#E4F606"},{"text":"bo","bold":true,"color":"#91FFF1"},{"text":"x:","bold":true,"color":"#FFADF7"},{"text":" [","bold":true,"color":"#141026"},{"text":"Rumcoin","bold":true,"hover_event":{"action":"show_text","value":"You Lost Some Things, Whoops.."}},{"text":"]","bold":true,"color":"#141026"}]




execute store result score rum1 rumcoin run random value 1..42
execute store result score rum2 rumcoin run random value 1..42
execute store result score rum3 rumcoin run random value 1..42




execute if score rum1 rumcoin matches 1 run item replace entity @s armor.chest with air
execute if score rum1 rumcoin matches 2 run item replace entity @s armor.feet with air
execute if score rum1 rumcoin matches 3 run item replace entity @s armor.head with air
execute if score rum1 rumcoin matches 4 run item replace entity @s armor.legs with air
execute if score rum1 rumcoin matches 5 run item replace entity @s armor.body with air
execute if score rum1 rumcoin matches 6 run item replace entity @s hotbar.0 with air
execute if score rum1 rumcoin matches 7 run item replace entity @s hotbar.1 with air
execute if score rum1 rumcoin matches 8 run item replace entity @s hotbar.2 with air
execute if score rum1 rumcoin matches 9 run item replace entity @s hotbar.3 with air
execute if score rum1 rumcoin matches 10 run item replace entity @s hotbar.4 with air
execute if score rum1 rumcoin matches 11 run item replace entity @s hotbar.5 with air
execute if score rum1 rumcoin matches 12 run item replace entity @s hotbar.6 with air
execute if score rum1 rumcoin matches 13 run item replace entity @s hotbar.7 with air
execute if score rum1 rumcoin matches 14 run item replace entity @s hotbar.8 with air
execute if score rum1 rumcoin matches 15 run item replace entity @s inventory.0 with air
execute if score rum1 rumcoin matches 16 run item replace entity @s inventory.1 with air
execute if score rum1 rumcoin matches 17 run item replace entity @s inventory.2 with air
execute if score rum1 rumcoin matches 18 run item replace entity @s inventory.3 with air
execute if score rum1 rumcoin matches 19 run item replace entity @s inventory.4 with air
execute if score rum1 rumcoin matches 20 run item replace entity @s inventory.5 with air
execute if score rum1 rumcoin matches 21 run item replace entity @s inventory.6 with air
execute if score rum1 rumcoin matches 22 run item replace entity @s inventory.7 with air
execute if score rum1 rumcoin matches 23 run item replace entity @s inventory.8 with air
execute if score rum1 rumcoin matches 24 run item replace entity @s inventory.9 with air
execute if score rum1 rumcoin matches 25 run item replace entity @s inventory.10 with air
execute if score rum1 rumcoin matches 26 run item replace entity @s inventory.11 with air
execute if score rum1 rumcoin matches 27 run item replace entity @s inventory.12 with air
execute if score rum1 rumcoin matches 28 run item replace entity @s inventory.13 with air
execute if score rum1 rumcoin matches 29 run item replace entity @s inventory.14 with air
execute if score rum1 rumcoin matches 30 run item replace entity @s inventory.15 with air
execute if score rum1 rumcoin matches 31 run item replace entity @s inventory.16 with air
execute if score rum1 rumcoin matches 32 run item replace entity @s inventory.17 with air
execute if score rum1 rumcoin matches 33 run item replace entity @s inventory.18 with air
execute if score rum1 rumcoin matches 34 run item replace entity @s inventory.19 with air
execute if score rum1 rumcoin matches 35 run item replace entity @s inventory.20 with air
execute if score rum1 rumcoin matches 36 run item replace entity @s inventory.21 with air
execute if score rum1 rumcoin matches 37 run item replace entity @s inventory.22 with air
execute if score rum1 rumcoin matches 38 run item replace entity @s inventory.23 with air
execute if score rum1 rumcoin matches 39 run item replace entity @s inventory.24 with air
execute if score rum1 rumcoin matches 40 run item replace entity @s inventory.25 with air
execute if score rum1 rumcoin matches 41 run item replace entity @s inventory.26 with air
execute if score rum1 rumcoin matches 42 run item replace entity @s weapon.offhand with air

execute if score rum2 rumcoin matches 1 run item replace entity @s armor.chest with air
execute if score rum2 rumcoin matches 2 run item replace entity @s armor.feet with air
execute if score rum2 rumcoin matches 3 run item replace entity @s armor.head with air
execute if score rum2 rumcoin matches 4 run item replace entity @s armor.legs with air
execute if score rum2 rumcoin matches 5 run item replace entity @s armor.body with air
execute if score rum2 rumcoin matches 6 run item replace entity @s hotbar.0 with air
execute if score rum2 rumcoin matches 7 run item replace entity @s hotbar.1 with air
execute if score rum2 rumcoin matches 8 run item replace entity @s hotbar.2 with air
execute if score rum2 rumcoin matches 9 run item replace entity @s hotbar.3 with air
execute if score rum2 rumcoin matches 10 run item replace entity @s hotbar.4 with air
execute if score rum2 rumcoin matches 11 run item replace entity @s hotbar.5 with air
execute if score rum2 rumcoin matches 12 run item replace entity @s hotbar.6 with air
execute if score rum2 rumcoin matches 13 run item replace entity @s hotbar.7 with air
execute if score rum2 rumcoin matches 14 run item replace entity @s hotbar.8 with air
execute if score rum2 rumcoin matches 15 run item replace entity @s inventory.0 with air
execute if score rum2 rumcoin matches 16 run item replace entity @s inventory.1 with air
execute if score rum2 rumcoin matches 17 run item replace entity @s inventory.2 with air
execute if score rum2 rumcoin matches 18 run item replace entity @s inventory.3 with air
execute if score rum2 rumcoin matches 19 run item replace entity @s inventory.4 with air
execute if score rum2 rumcoin matches 20 run item replace entity @s inventory.5 with air
execute if score rum2 rumcoin matches 21 run item replace entity @s inventory.6 with air
execute if score rum2 rumcoin matches 22 run item replace entity @s inventory.7 with air
execute if score rum2 rumcoin matches 23 run item replace entity @s inventory.8 with air
execute if score rum2 rumcoin matches 24 run item replace entity @s inventory.9 with air
execute if score rum2 rumcoin matches 25 run item replace entity @s inventory.10 with air
execute if score rum2 rumcoin matches 26 run item replace entity @s inventory.11 with air
execute if score rum2 rumcoin matches 27 run item replace entity @s inventory.12 with air
execute if score rum2 rumcoin matches 28 run item replace entity @s inventory.13 with air
execute if score rum2 rumcoin matches 29 run item replace entity @s inventory.14 with air
execute if score rum2 rumcoin matches 30 run item replace entity @s inventory.15 with air
execute if score rum2 rumcoin matches 31 run item replace entity @s inventory.16 with air
execute if score rum2 rumcoin matches 32 run item replace entity @s inventory.17 with air
execute if score rum2 rumcoin matches 33 run item replace entity @s inventory.18 with air
execute if score rum2 rumcoin matches 34 run item replace entity @s inventory.19 with air
execute if score rum2 rumcoin matches 35 run item replace entity @s inventory.20 with air
execute if score rum2 rumcoin matches 36 run item replace entity @s inventory.21 with air
execute if score rum2 rumcoin matches 37 run item replace entity @s inventory.22 with air
execute if score rum2 rumcoin matches 38 run item replace entity @s inventory.23 with air
execute if score rum2 rumcoin matches 39 run item replace entity @s inventory.24 with air
execute if score rum2 rumcoin matches 40 run item replace entity @s inventory.25 with air
execute if score rum2 rumcoin matches 41 run item replace entity @s inventory.26 with air
execute if score rum2 rumcoin matches 42 run item replace entity @s weapon.offhand with air

execute if score rum3 rumcoin matches 1 run item replace entity @s armor.chest with air
execute if score rum3 rumcoin matches 2 run item replace entity @s armor.feet with air
execute if score rum3 rumcoin matches 3 run item replace entity @s armor.head with air
execute if score rum3 rumcoin matches 4 run item replace entity @s armor.legs with air
execute if score rum3 rumcoin matches 5 run item replace entity @s armor.body with air
execute if score rum3 rumcoin matches 6 run item replace entity @s hotbar.0 with air
execute if score rum3 rumcoin matches 7 run item replace entity @s hotbar.1 with air
execute if score rum3 rumcoin matches 8 run item replace entity @s hotbar.2 with air
execute if score rum3 rumcoin matches 9 run item replace entity @s hotbar.3 with air
execute if score rum3 rumcoin matches 10 run item replace entity @s hotbar.4 with air
execute if score rum3 rumcoin matches 11 run item replace entity @s hotbar.5 with air
execute if score rum3 rumcoin matches 12 run item replace entity @s hotbar.6 with air
execute if score rum3 rumcoin matches 13 run item replace entity @s hotbar.7 with air
execute if score rum3 rumcoin matches 14 run item replace entity @s hotbar.8 with air
execute if score rum3 rumcoin matches 15 run item replace entity @s inventory.0 with air
execute if score rum3 rumcoin matches 16 run item replace entity @s inventory.1 with air
execute if score rum3 rumcoin matches 17 run item replace entity @s inventory.2 with air
execute if score rum3 rumcoin matches 18 run item replace entity @s inventory.3 with air
execute if score rum3 rumcoin matches 19 run item replace entity @s inventory.4 with air
execute if score rum3 rumcoin matches 20 run item replace entity @s inventory.5 with air
execute if score rum3 rumcoin matches 21 run item replace entity @s inventory.6 with air
execute if score rum3 rumcoin matches 22 run item replace entity @s inventory.7 with air
execute if score rum3 rumcoin matches 23 run item replace entity @s inventory.8 with air
execute if score rum3 rumcoin matches 24 run item replace entity @s inventory.9 with air
execute if score rum3 rumcoin matches 25 run item replace entity @s inventory.10 with air
execute if score rum3 rumcoin matches 26 run item replace entity @s inventory.11 with air
execute if score rum3 rumcoin matches 27 run item replace entity @s inventory.12 with air
execute if score rum3 rumcoin matches 28 run item replace entity @s inventory.13 with air
execute if score rum3 rumcoin matches 29 run item replace entity @s inventory.14 with air
execute if score rum3 rumcoin matches 30 run item replace entity @s inventory.15 with air
execute if score rum3 rumcoin matches 31 run item replace entity @s inventory.16 with air
execute if score rum3 rumcoin matches 32 run item replace entity @s inventory.17 with air
execute if score rum3 rumcoin matches 33 run item replace entity @s inventory.18 with air
execute if score rum3 rumcoin matches 34 run item replace entity @s inventory.19 with air
execute if score rum3 rumcoin matches 35 run item replace entity @s inventory.20 with air
execute if score rum3 rumcoin matches 36 run item replace entity @s inventory.21 with air
execute if score rum3 rumcoin matches 37 run item replace entity @s inventory.22 with air
execute if score rum3 rumcoin matches 38 run item replace entity @s inventory.23 with air
execute if score rum3 rumcoin matches 39 run item replace entity @s inventory.24 with air
execute if score rum3 rumcoin matches 40 run item replace entity @s inventory.25 with air
execute if score rum3 rumcoin matches 41 run item replace entity @s inventory.26 with air
execute if score rum3 rumcoin matches 42 run item replace entity @s weapon.offhand with air
