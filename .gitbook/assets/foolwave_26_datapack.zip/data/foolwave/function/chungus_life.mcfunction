
effect give @s minecraft:saturation 1 5

advancement revoke @s only minecraft:foolwave/chungus_life_kill
advancement revoke @s only minecraft:foolwave/chungus_life_break