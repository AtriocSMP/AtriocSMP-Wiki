execute as @s at @s run loot give @s loot minecraft:gameplay/crates/items/wind

schedule function foolwave:item/wind_charge_infinite2 2t