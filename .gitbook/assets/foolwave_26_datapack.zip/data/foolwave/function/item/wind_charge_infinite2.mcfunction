
advancement revoke @a only minecraft:foolwave/wind_charge_infinite