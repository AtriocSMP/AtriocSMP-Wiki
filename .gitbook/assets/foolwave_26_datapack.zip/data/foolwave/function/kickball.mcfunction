execute store result score kickball kickball run random value 1..2000

execute if score kickball kickball matches 1 run execute as @a as @s at @s run playsound minecraft:item.brainrot.sound.kickball master @s ~ ~ ~ 100
execute if score kickball kickball matches 1 run say Kickball POGGIES
