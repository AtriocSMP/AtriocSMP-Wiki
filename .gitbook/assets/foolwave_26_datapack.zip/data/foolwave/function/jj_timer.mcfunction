title @s times 5t 1s 5t

execute if score @s jj_timer matches 4 run title @s title {text:"3",color:"red",italic:0b}
execute if score @s jj_timer matches 3 run title @s title {text:"2",color:"red",italic:0b}
execute if score @s jj_timer matches 2 run title @s title {text:"1",color:"red",italic:0b}
execute if score @s jj_timer matches 1 run title @s title {text:"0",color:"red",italic:0b}

#execute if score @s jj_timer matches 4 run say 4
#execute if score @s jj_timer matches 3 run say 3
#execute if score @s jj_timer matches 2 run say 2
#execute if score @s jj_timer matches 1 run say 1

scoreboard players remove @s jj_timer 1

execute if score @s jj_timer matches 0 run summon minecraft:tnt ~ ~ ~ {fuse:0}