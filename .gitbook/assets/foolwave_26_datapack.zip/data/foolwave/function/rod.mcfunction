advancement revoke @s only minecraft:foolwave/rod

summon minecraft:lightning_bolt ~ ~ ~