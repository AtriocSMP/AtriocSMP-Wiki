
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/diamond

advancement revoke @s only minecraft:foolwave/diamond_crate