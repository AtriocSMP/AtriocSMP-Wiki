
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/copper

advancement revoke @s only minecraft:foolwave/copper_crate