
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/amethyst

advancement revoke @s only minecraft:foolwave/amethyst_crate