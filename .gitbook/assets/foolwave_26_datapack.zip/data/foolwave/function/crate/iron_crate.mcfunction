
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/iron

advancement revoke @s only minecraft:foolwave/iron_crate