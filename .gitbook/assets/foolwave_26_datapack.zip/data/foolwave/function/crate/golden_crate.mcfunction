
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/golden

advancement revoke @s only minecraft:foolwave/golden_crate