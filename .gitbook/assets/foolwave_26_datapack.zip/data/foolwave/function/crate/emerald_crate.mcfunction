
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/emerald

advancement revoke @s only minecraft:foolwave/emerald_crate