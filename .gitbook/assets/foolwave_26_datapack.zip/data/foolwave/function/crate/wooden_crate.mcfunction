
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/wooden

advancement revoke @s only minecraft:foolwave/wooden_crate