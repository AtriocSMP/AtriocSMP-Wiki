
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/netherite

advancement revoke @s only minecraft:foolwave/netherite_crate