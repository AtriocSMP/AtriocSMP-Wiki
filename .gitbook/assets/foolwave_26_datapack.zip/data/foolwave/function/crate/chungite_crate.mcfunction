
execute at @s run loot spawn ~ ~ ~ loot minecraft:gameplay/crates/chungite

advancement revoke @s only minecraft:foolwave/chungite_crate